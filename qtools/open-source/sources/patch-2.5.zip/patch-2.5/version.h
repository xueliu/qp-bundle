/* Print the version number.  */

/* $Id: version.h,v 1.1.1.1 2000/08/16 00:20:10 syring Exp $ */

void version PARAMS ((void));
