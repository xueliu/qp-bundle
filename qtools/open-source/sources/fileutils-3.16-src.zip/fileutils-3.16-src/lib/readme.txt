06.09.99
slash/backslash problem fixed in basename.c and stripslash.c

=== File list for win32 ==
yesno.c  xstrtoul.c  xstrtol.c  xstrdup.c  xmalloc.c  xgetcwd.c  userspec.c  stripslash.c  strcasecmp.c  stpcpy.c  savedir.c  save-cwd.c  safe-read.c  rx.c  rpmatch.c   posixtm.c  path-concat.c  obstack.c  mountlist.c  modechange.c  mktime.c  makepath.c  long-options.c  isdir.c  idcache.c  group-member.c  getversion.c  getopt1.c  getopt.c  getline.c  getdate.c  full-write.c  fnmatch.c  filemode.c  fileblocks.c  euidaccess.c  error.c  dirname.c  basename.c  backupfile.c  argmatch.c  

everything compiles without downhill except of backupfile.c (dirent is missing)
better not for pure Win32: euidaccess.c userspec.c